# Battle Zone — TDM Arena (Phase 3)

لعبة حركة ثلاثية الأبعاد جاهزة للموبايل، مبنية على Three.js.

## المميزات الحالية
- خريطة TDM حقيقية (`map.glb`)
- شخصية Toon Soldier متحركة (Idle / Run / Jump)
- سلاح AK-47 مرئي في وضع TPS
- أصوات خطوات + هبوط (Kenney Impact)
- تحكم لمس كامل + كيبورد/ماوس
- كاميرا FPS ↔ TPS
- شاشة تحميل + كروس هير
- جاهزة لاحقاً لـ Capacitor → APK

## تشغيل محلي
```bash
npx serve .
# أو
python3 -m http.server 8080
```
افتح `http://localhost:8080`

## هيكل المشروع
```
assets/
  models/   map, soldier, ak47, enemy, ...
  sounds/   footsteps + impacts
src/
  audio/    AudioManager
  core/     Loop + math
  input/    Touch + Keyboard
  render/   GameRenderer + Avatar (animations)
  systems/  CharacterController + CameraRig
  world/    World (AABB) + Level
```

## تحويلها لتطبيق Android (APK)
1. ثبت Capacitor:
   ```bash
   npm init -y
   npm i @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Battle Zone" com.yourname.battlezone
   npx cap add android
   ```
2. غيّر `webDir` في `capacitor.config.json` إلى `.` أو انسخ الملفات إلى `www/`
3. `npx cap sync android`
4. افتح Android Studio → Build → Generate Signed Bundle / APK

## ملاحظات
- الاصطدام على الخريطة تقريبي (AABBs يدوية). لتحسينه لاحقاً استخدم BVH.
- الشخصية الأصلية (android.glb) كانت ثقيلة فاستُبدلت بـ Toon Soldier.
- الأصول من Kenney + Toon Shooter Kit.
