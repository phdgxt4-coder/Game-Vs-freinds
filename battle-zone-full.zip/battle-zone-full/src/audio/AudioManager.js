/** Lightweight pooled audio for footsteps / impacts. */
export class AudioManager {
  constructor() {
    this.ctx = null;
    this.buffers = new Map();
    this.enabled = true;
    this._footIdx = 0;
  }

  async init() {
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      const files = [
        'footstep_concrete_000', 'footstep_concrete_001', 'footstep_concrete_002',
        'footstep_concrete_003', 'footstep_concrete_004',
        'impactGeneric_light_000', 'impactGeneric_light_001', 'impactGeneric_light_002',
      ];
      await Promise.all(files.map(async (name) => {
        const res = await fetch(`./assets/sounds/${name}.ogg`);
        const arr = await res.arrayBuffer();
        const buf = await this.ctx.decodeAudioData(arr);
        this.buffers.set(name, buf);
      }));
    } catch (e) {
      console.warn('Audio init failed', e);
      this.enabled = false;
    }
  }

  resume() {
    if (this.ctx?.state === 'suspended') this.ctx.resume();
  }

  play(name, { volume = 0.6, rate = 1 } = {}) {
    if (!this.enabled || !this.ctx || !this.buffers.has(name)) return;
    const src = this.ctx.createBufferSource();
    const gain = this.ctx.createGain();
    src.buffer = this.buffers.get(name);
    src.playbackRate.value = rate;
    gain.gain.value = volume;
    src.connect(gain);
    gain.connect(this.ctx.destination);
    src.start(0);
  }

  footstep(speed) {
    if (speed < 0.8) return;
    const names = [
      'footstep_concrete_000', 'footstep_concrete_001', 'footstep_concrete_002',
      'footstep_concrete_003', 'footstep_concrete_004',
    ];
    const name = names[this._footIdx++ % names.length];
    const vol = Math.min(0.55, 0.25 + speed * 0.04);
    const rate = 0.9 + Math.random() * 0.2;
    this.play(name, { volume: vol, rate });
  }

  land(impact) {
    const vol = Math.min(0.8, 0.3 + impact * 0.15);
    this.play('impactGeneric_light_00' + Math.floor(Math.random() * 3), { volume: vol, rate: 0.85 + Math.random() * 0.2 });
  }
}
