import * as THREE from 'three';

/**
 * Builds the playable space.
 * - Visual: the provided TDM map GLB (centered, y-adjusted).
 * - Collision: large ground plane + a few key structural AABBs so movement
 *   still feels solid while the detailed mesh is visual-only (full mesh
 *   collision would need a BVH / physics engine).
 */
export function buildLevel(scene, world, mapScene) {
  // Ground collision (map sits roughly on y=0 after offset)
  world.addBox(-80, -2, -80, 80, 0.02, 80);

  if (mapScene) {
    // Map original: y min ≈ -1, center y ≈ 3.7 → lift so floor is near 0
    mapScene.position.y = 1.05;
    mapScene.traverse((c) => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
        c.frustumCulled = true;
        if (c.material) {
          const mats = Array.isArray(c.material) ? c.material : [c.material];
          mats.forEach((m, i) => {
            if (m && m.isMeshBasicMaterial) {
              const lm = new THREE.MeshLambertMaterial({
                color: m.color?.clone?.() || 0x888888,
                map: m.map,
                transparent: m.transparent,
                opacity: m.opacity,
                side: m.side || THREE.FrontSide,
              });
              if (Array.isArray(c.material)) c.material[i] = lm;
              else c.material = lm;
            }
          });
        }
      }
    });
    scene.add(mapScene);

    // Approximate solid volumes for main structures (hand-tuned from map bounds)
    // Outer walls / cover blocks – coarse but prevents total freefall look
    const solid = (x0, y0, z0, x1, y1, z1) => world.addBox(x0, y0, z0, x1, y1, z1);

    // Central buildings / containers (typical TDM layout)
    solid(-12, 0, -8, -4, 3.2, 0);
    solid(4, 0, -6, 12, 3.2, 2);
    solid(-18, 0, 10, -10, 4.0, 18);
    solid(8, 0, 12, 16, 3.5, 20);
    solid(-6, 0, 22, 6, 2.8, 28);
    // Side cover
    solid(-28, 0, -20, -22, 2.5, -8);
    solid(22, 0, -18, 28, 2.5, -6);
    // Low barriers
    solid(-15, 0, 4, -8, 1.2, 6);
    solid(8, 0, -12, 15, 1.2, -10);
  } else {
    // Fallback procedural test range if map failed to load
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const mats = new Map();
    const mat = (c) => {
      let m = mats.get(c);
      if (!m) mats.set(c, (m = new THREE.MeshLambertMaterial({ color: c })));
      return m;
    };
    const solid = (x0, y0, z0, x1, y1, z1, color) => {
      const m = new THREE.Mesh(geo, mat(color));
      m.scale.set(x1 - x0, y1 - y0, z1 - z0);
      m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
      m.castShadow = m.receiveShadow = true;
      scene.add(m);
      world.addBox(x0, y0, z0, x1, y1, z1);
    };
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(200, 200),
      new THREE.MeshLambertMaterial({ color: 0x6f9a58 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    [0.3, 0.6, 1.0, 1.4, 2.2].forEach((h, i) =>
      solid(-7 + i * 3.5, 0, -10, -5.4 + i * 3.5, h, -8.4, 0xc98a4b)
    );
  }
}
