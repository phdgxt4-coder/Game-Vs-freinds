import * as THREE from 'three';
import { CONFIG } from '../config.js';

/**
 * Animated toon soldier + weapon.
 * Contract: root (Object3D), update(state, yaw, dt), setModels(soldierGltf, weaponGltf)
 */
export class Avatar {
  constructor() {
    this.root = new THREE.Group();
    this.mixer = null;
    this.actions = {};
    this.current = null;
    this._weapon = null;
    this._ready = false;
    this._scale = 0.032; // ~53 units → ~1.7 m

    const mat = new THREE.MeshLambertMaterial({ color: 0x4a7c59 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 1.16, 4, 8), mat);
    body.position.y = 0.9;
    body.castShadow = true;
    this.root.add(body);
    this._placeholder = body;
  }

  setModels(soldierGltf, weaponGltf) {
    if (this._placeholder) {
      this.root.remove(this._placeholder);
      this._placeholder = null;
    }

    const model = soldierGltf.scene;
    model.scale.setScalar(this._scale);
    model.traverse((c) => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
        c.frustumCulled = true;
      }
    });
    this.root.add(model);

    this.mixer = new THREE.AnimationMixer(model);
    const clips = soldierGltf.animations || [];
    const find = (part) => clips.find((c) => c.name.includes(part));
    const add = (key, clip) => {
      if (!clip) return;
      const act = this.mixer.clipAction(clip);
      act.enabled = true;
      this.actions[key] = act;
    };
    add('idle', clips.find((c) => c.name.endsWith('|Idle') || (c.name.includes('Idle') && !c.name.includes('Shoot'))));
    add('run', find('Run_Gun') || find('Run'));
    add('jump', find('Jump'));
    add('land', find('Jump_Land'));
    add('shoot', find('Idle_Shoot'));

    if (weaponGltf) {
      const w = weaponGltf.scene.clone(true);
      w.scale.setScalar(1.15);
      // Rough right-hand offset after character scale
      w.position.set(0.28, 1.05, 0.22);
      w.rotation.set(-0.15, Math.PI, 0.05);
      w.traverse((c) => {
        if (c.isMesh) {
          c.castShadow = true;
          c.frustumCulled = true;
        }
      });
      this.root.add(w);
      this._weapon = w;
    }

    this._play('idle');
    this._ready = true;
  }

  _play(name, fade = 0.15) {
    if (!this.actions[name] || this.current === name) return;
    const next = this.actions[name];
    if (this.current && this.actions[this.current]) {
      this.actions[this.current].fadeOut(fade);
    }
    next.reset().setEffectiveTimeScale(1).setEffectiveWeight(1).fadeIn(fade).play();
    this.current = name;
  }

  update(s, yaw, dt = 1 / 60) {
    this.root.position.set(s.x, s.y, s.z);
    this.root.rotation.y = yaw;

    if (!this._ready || !this.mixer) {
      if (this._placeholder) this.root.scale.y = s.eye / CONFIG.player.eyeStand;
      return;
    }

    this.mixer.update(dt);

    const grounded = s.grounded !== false;
    const moving = (s.speed || 0) > 1.2;
    if (!grounded) this._play('jump', 0.08);
    else if (moving) this._play('run', 0.12);
    else this._play('idle', 0.2);
  }
}
